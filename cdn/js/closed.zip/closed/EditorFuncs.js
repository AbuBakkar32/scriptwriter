class EditorFuncs {
    // Buttons
    boldBtn; //Bold button
    italicBtn; // italic button
    underlineBtn; // underline button
    penPaintBtn; //penPaint button or highlight
    textColorBtn; //Text Color
    voiceRecordBtn; //Voice Record button
    audioPlayReaderBtn; //audio play reader button
    downloadBtn; // download button
    shareBtn; // share button
    saveBtn; // Save button
    // Page Management -> creating, adjust and deleting of page.(i.e) Script writer content page template and wrapper
    swPageWrapperTemp = document.querySelector(`[sw-page-pack="list"]`);
    swPageTemp = document.querySelector(`[sw-page-pack="item"]`).cloneNode(true);
    contentLineTemp = document.querySelector(`[sw-data="content-line"]`).cloneNode(true);
    //Artificial voice
    recognition;
    //Artificial speak
    speechControl = window.speechSynthesis;
    // Newly created script-body
    newlyCreatedContentLine;
    // constant height size of any page in the script Document
    swPageHeight = 1130; //640;
    // Status for wrapper in share button
    shareWrapStatus = [];
    // const for speech recognition not support
    srNotSupportedText = 'This browser does not support voice recording and writing. Switch to a chrome browser!';
    // new content line created status
    freshContentLineAvalible = false;
    constructor() {
        // Buttons initializer
        this.boldBtn = document.querySelectorAll(`[sw-btn="bold"]`);
        this.italicBtn = document.querySelectorAll(`[sw-btn="italic"]`);
        this.underlineBtn = document.querySelectorAll(`[sw-btn="underline"]`);
        this.penPaintBtn = document.querySelectorAll(`[sw-btn="penPaint"]`);
        this.textColorBtn = document.querySelectorAll(`[sw-btn="textColor"]`);
        this.voiceRecordBtn = document.querySelectorAll(`[sw-btn="voiceRecord"]`);
        this.audioPlayReaderBtn = document.querySelectorAll(`[sw-btn="audioPlayReader"]`);
        this.downloadBtn = document.querySelectorAll(`[sw-btn="download"]`);
        this.shareBtn = document.querySelectorAll(`[sw-btn="share"]`);
        this.saveBtn = document.querySelectorAll(`[sw-btn="save"]`);
        // the very first content-line
        this.newlyCreatedContentLine = document.querySelector(`[sw-data="content-line"]`);
        //Init
        this.listener();
    }

    listener() {
        //Initializing script writing editor
        this.swContentLine();

        //Inintialize Artificial Voice
        try {
            this.initRecorder();
        } catch (error) {
            console.log(this.srNotSupportedText);
            alert(this.srNotSupportedText);
        }

        // Click event listener for the buttons
        this.boldBtn.forEach((btn) => { btn.addEventListener('click', () => {this.bold(); this.share(); }) });
        this.italicBtn.forEach((btn) => { btn.addEventListener('click', () => { this.italic(); this.share(); }) });
        this.underlineBtn.forEach((btn) => { btn.addEventListener('click', () => { this.underline(); this.share(); }) });
        this.downloadBtn.forEach((btn) => { btn.addEventListener('click', () => { this.download(); this.share(); }) });
        this.saveBtn.forEach((btn) => { btn.addEventListener('click', () => { this.save(); this.share(); }) });
        this.shareBtn.forEach((btn) => { this.shareWrapStatus.push(false); btn.addEventListener('click', () => { this.share(btn);})});

        //Highlight
        this.penPaintBtn.forEach((btn) => {
            let openStatus = true;
            btn.addEventListener('click', () => {
                // Hide the share wrap
                this.share();

                const colorElement = btn.querySelector(`input[type="color"]`);
                if (openStatus) {
                    openStatus = false;
                    colorElement.style.display = 'block';
                    this.penPaint(colorElement.value)
                } else {
                    openStatus = true;
                    colorElement.style.display = '';
                    this.penPaint(null);
                }
            })
        });
        
        //Apply color text
        this.textColorBtn.forEach((btn) => {
            let openStatus = true;
            btn.addEventListener('click', () => {
                // Hide the share wrap
                this.share();

                const colorElement = btn.querySelector(`input[type="color"]`);
                if (openStatus) {
                    openStatus = false;
                    colorElement.style.display = 'block';
                    this.colorText(colorElement.value)
                } else {
                    openStatus = true;
                    colorElement.style.display = '';
                }
            }) 
        });

        // Color Picker listerner
        this.renderColorAttr();

        //Record voice function
        this.voiceRecordBtn.forEach((btn) => {
            let recordStatus = true;
            btn.addEventListener('click', () => {
                // Hide the share wrap
                this.share();
                
                // Confirm that SpeechRecognition is active on this browser
                if (this.recognition) {
                    if (recordStatus) {
                        this.recognition.start(); recordStatus = false;
                    } else {
                        this.recognition.stop(); recordStatus = true;
                    }
                } else alert(this.srNotSupportedText);
            });
        });

        // Play text
        this.audioPlayReaderBtn.forEach((btn) => {
            let textPlayStatus = true;
            btn.addEventListener('click', () => {
                // Hide the share wrap
                this.share();
                // Confirm that SpeechRecognition is active on this browser
                if (this.recognition) {
                    if (textPlayStatus) {
                        this.audioPlayReader(); textPlayStatus = false;
                    } else {
                        this.speechControl.cancel(); textPlayStatus = true;
                    }
                } else alert(this.srNotSupportedText);
            });
        });

        // Refresh the total number of pages avaliable.
        this.totalNumberOfPage();
    }

    generateID() {
        let id = '0';
        const allScriptBody = document.querySelectorAll(`[sw-data="script-body"]`);
        const lastScriptBody = allScriptBody[(allScriptBody.length - 1)]?.parentElement;
        if (lastScriptBody) {
            const xid = lastScriptBody.querySelector(`[sw-script-body="id"]`).textContent;
            id += String(Number(xid.substr(1)) + 1);
        } else id += '0';
        
        //const check = document.querySelector(`[sw-script-body-idvalue="${id}"]`);
        const scriptIDList = [];
        document.querySelectorAll(`[sw-script-body="id"]`).forEach((i) => { scriptIDList.push(i.textContent); });
        let count = 1;
        while (true) {
            count += 1;
            if (scriptIDList.includes(id)) {
                id = '0';
                if (lastScriptBody) {
                    const xid = lastScriptBody.querySelector(`[sw-script-body="id"]`).textContent;
                    id += String(Number(xid.substr(1)) + count);
                } else id += String(count);
            } else break;
        }

        return id;
    }

    renderColorAttr() {
        document.querySelectorAll(`[render-color]`).forEach((ele) => {
            ele.addEventListener('click', (e) => {
                e.stopImmediatePropagation();
                e.stopPropagation();
            });

            //Watch for change in color value
            ele.addEventListener('change', (f) => {
                f.stopImmediatePropagation();
                f.stopPropagation();
                console.log(ele.value);
                //if (ele.getAttribute('render-color') === 'textColor') this.colorText(ele.value);
                //else if (ele.getAttribute('render-color') === 'highlight') this.penPaint(ele.value)
            });
        });
    }

    captureSelection() {
        // capture the current selection
        const selected = window.getSelection();
        if (selected.toString()) return selected;
        else return null;
    }

    initSelection(type) {
        const capSelect = this.captureSelection();
        if (capSelect){
            //If the selection parent is a div, that means the selection has no style on it yet.
            //if (capSelect.baseNode.parentElement.tagName === 'DIV') {
                //Create style element 
                const font = document.createElement('font');
                if (type === 'background') font.style.backgroundColor = '';
                else font.style.color = '';
                font.textContent = capSelect.toString();
                //Add the style to the text and replace it with the initial one.
                const range = sel.getRangeAt(0);
                range.deleteContents();
                range.insertNode(font);

            //} else if (capSelect.baseNode.parentElement.tagName === 'FONT') {
                // Else the selection has a style, which means, is either the style is removed, adjusted or new one is added.

            //}
        }
        
    }

    bold() {
        document.execCommand('bold'/* , false, null */);
    }

    italic() {
        document.execCommand('italic'/* , false, null */);
    }

    underline() {
        document.execCommand('underline'/* , false, null */);
    }

    penPaint(color) {
        //document.execCommand('backColor'/* , false, null */);
        // change text background color   
        /* if( !document.execCommand( "hiliteColor", true, color) ){    
            document.execCommand( "backColor", true, color )        
            document.execCommand( "insertText", true, " " ); 
            // executes backColor command if hiliteColor returns false, indicating browser is internet explorer         
        }    */
        document.execCommand( "backColor", false, color ) 
    }

    colorText(color) {
        document.execCommand('foreColor', true, color);
    }

    voiceRecord() {}
    
    audioPlayReader() {
        const contentLine = document.querySelector(`[sw-focused="edit"]`);
        if (contentLine) {
            // the script body or the div containing contenteditable
            const scriptBody = contentLine.querySelector(`[sw-data="script-body"]`);
            if (scriptBody.innerText){
                // Stop recognition ( voice recording )
                this.recognition.stop();

                const speech = new SpeechSynthesisUtterance();
                // Set the text and voice attributes.
                speech.text = scriptBody.innerText;
                speech.volume = 1;
                speech.rate = 1;
                speech.pitch = 1;
                this.speechControl.speak(speech);
            }
        }
        //window.speechSynthesis.pause()
    }

    initRecorder() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        this.speechControl = window.speechSynthesis;

        this.recognition.continuous = true;

        // This block is called every time the Speech APi captures a line. 
        this.recognition.onresult = function(event) {
            // event is a SpeechRecognitionEvent object. It holds all the lines we have captured so far. We only need the current one.
            const current = event.resultIndex;

            // Get a transcript of what was said.
            const transcript = event.results[current][0].transcript;
            // Add the current transcript to the contents of our Note. There is a weird bug on mobile, where everything is repeated twice.
            // There is no official solution so far so we have to handle an edge case.
            const mobileRepeatBug = (current == 1 && transcript == event.results[0][0].transcript);
            if(!mobileRepeatBug) {
                //noteContent += transcript;
                //noteTextarea.val(noteContent);
                const contentLine = document.querySelector(`[sw-focused="edit"]`);
                if (contentLine) {
                    // the script body or the div containing contenteditable
                    const scriptBody = contentLine.querySelector(`[sw-data="script-body"]`);
                    // Add the voice captured text to the current 
                    scriptBody.textContent = scriptBody.textContent + transcript;
                }
            }
        };

        this.recognition.onstart = function() { 
            console.log('Voice recognition activated. Try speaking into the microphone.');
        }
          
        this.recognition.onspeechend = function() {
            console.log('You were quiet for a while so voice recognition turned itself off.');
        }
          
        this.recognition.onerror = function(event) {
            if(event.error == 'no-speech') {
                console.log('No speech was detected. Try again.');  
            };
        }
    }

    download() {
        //window.location = '/cdn/store/sample.pdf'
        fetch(location.href + '/download', {method: 'GET'})
        .then(response => response.json())
        .then(data => {
            if (data.file) window.location = '/cdn/store/'+data.file;
            else alert('Cannot download script document at this time, An internal error has occoured');
        }).catch((error) => {
            alert('Cannot download script document at this time, An internal error has occoured');
            console.log(error);
        })
    }

    share(shareBtnWrap = null) {
        if (shareBtnWrap) {
            const index = window.getEleId(shareBtnWrap, this.shareBtn);
            if (!this.shareWrapStatus[index]){
                this.shareWrapStatus[index] = true;
                shareBtnWrap.querySelector(`[sw-share="wrap"]`).classList.remove('hide');
            }else {
                this.shareWrapStatus[index] = false;
                shareBtnWrap.querySelector(`[sw-share="wrap"]`).classList.add('hide');
            }
        } else {
            this.shareWrapStatus.forEach((e) => {e = false});
            document.querySelectorAll(`[sw-share="wrap"]`).forEach((wrap) => {
                wrap.classList.add('hide');
            })
        }
    }

    save() {
        if (confirm('Do you want to save your content')) {
            // ScriptAdapter.js method:
            window.ScriptAdapter.save();
        }
    }

    /* Create content line/script body/new contenteditable  section starts here*/
    swContentLine() {
        const contentLine = document.querySelectorAll(`[sw-data="content-line"]`);
    
        contentLine.forEach((conl) => {
            // Hover feature
            this.hoverSelf(conl);
            // Enter key Feature
            this.keyPressSelf(conl);
        });
        //this.pageListeners();
    }
    
    hoverSelf(conl = document.querySelector(`[sw-data="content-line"]`)) {
        // Script Body
        const scriptBody = conl.querySelector(`[sw-data="script-body"]`);
        // icon at the left-hand of the script body
        const noteIcon = conl.querySelector(`[sw-data-content="note-icon"]`);
        // icon at the right-hand of the script body
        const commentIcon = conl.querySelector(`[sw-data-content="comment-icon"]`);
        //Note wrapper
        const noteWrap = conl.querySelector(`[sw-data-content="note-wrap"]`);
        // comment wrapper
        const commentWrap = conl.querySelector(`[sw-data-content="comment-wrap"]`);
        // comment ok button
        const commentOkBtn = conl.querySelector(`[sw-data-content="comment-btn-ok"]`);
        // comment cancel button
        const commentCancelBtn = conl.querySelector(`[sw-data-content="comment-btn-cancel"]`);
        // note ok button
        const noteOkBtn = conl.querySelector(`[sw-data-content="note-btn-ok"]`)
        // note cancel button
        const noteCancelBtn = conl.querySelector(`[sw-data-content="note-btn-cancel"]`)
        // icons visibility state 
        let hoverStatus = false;
        // Certainty on query elements else end method.
        let trust = noteIcon && commentIcon && noteWrap && commentWrap && scriptBody && conl.getAttribute('sw-data') != 'content-line';
        if (trust === null) trust = false;
        else if (trust === false) trust = true;
        if (!trust) return;
        
        conl.addEventListener('mouseover', function(){
            if (noteIcon.classList.contains('op-0')){
                noteIcon.classList.replace('op-0', 'op-1');
                commentIcon.classList.replace('op-0', 'op-1');
            }
        });

        // On mouseout event hide the content line icons
        conl.addEventListener('mouseout', () => {
            if (!conl.getAttribute('sw-focused')) {
                noteIcon.classList.replace('op-1', 'op-0');
                commentIcon.classList.replace('op-1', 'op-0');
                // hide note wrapper
                //noteWrap.classList.add('hide');
            }
        });

        //sw-focused="edit"
        // On focus event show the content line icons
        conl.addEventListener('focus', () => {
            noteIcon.classList.replace('op-0', 'op-1');
            commentIcon.classList.replace('op-0', 'op-1');
        });

        // On focusout or blur event hide the content line icons
        conl.addEventListener('focusout', () => {
            noteIcon.classList.replace('op-1', 'op-0');
            commentIcon.classList.replace('op-1', 'op-0');
            // hide note wrapper
            //noteWrap.classList.add('hide');
        });

        // Click event on noteIcon
        noteIcon?.addEventListener('click', () => {
            // Open note wrapper
            if (noteWrap.classList.contains('hide')) noteWrap.classList.remove('hide');
            else noteWrap.classList.add('hide');
        });
        // Click event on commentIcon
        commentIcon?.addEventListener('click', () => {
            // Open comment wrapper
            if (commentWrap.classList.contains('hide')) commentWrap.classList.remove('hide');
            else commentWrap.classList.add('hide');
        });
        // Click event on comment ok btn
        //commentOkBtn?.addEventListener('click', () => { commentWrap.classList.add('hide') });
        // Click event on comment cancel button
        commentCancelBtn?.addEventListener('click', () => { commentWrap.classList.add('hide') });
        // Click event on note ok btn
        //noteOkBtn?.addEventListener('click', () => { noteWrap.classList.add('hide') });
        // Click event on note cancel button
        noteCancelBtn?.addEventListener('click', () => { noteWrap.classList.add('hide') });
    }

    keyPressSelf(conl) {
        // Take note keydown event is faster than input input
        const scriptLine = conl?.querySelector(`[sw-data="script-body"]`);
        // id of the content line
        const clID = conl.getAttribute('contentline-id');
        let key = '';
        scriptLine?.addEventListener('keydown', (e) => {
            //console.log('Keydown Change on ', scriptLine.parentElement.getAttribute('contentline-id'));
            const pressedKey = e.key;
            const target = e.target;
            key = pressedKey;
            // the latest text from scriptLine
            const currentText = target.innerText;
            if (pressedKey === 'Enter') {
                e.preventDefault();
                // new content line var
                let newContentLine = null;
                const enterKeyPromise = new Promise((resolve, reject)=> {resolve(1)});
                enterKeyPromise.then(()=> {
                    // remove the div br element in the last script body
                    setTimeout( function(){ 
                        target.querySelectorAll('div>br').forEach((brEle) => { brEle.parentElement.remove();});
                    }, 20);
                }).then(()=> {
                    // create new content Line
                    newContentLine = this.createNewLine(conl);

                    // Neutralize the script element body
                    this.swHandleContentLineNuetral(target);

                    // character indicator
                    let isCharacter = false;

                    // Run type of script body
                    if (this.swHandleExtType(target));
                    else if (this.swHandleIntType(target));
                    else if (this.swHandleCharater(target)) isCharacter = true;
                    else if (this.swHandleParentArticle(target));
                    else if (this.swHandleDialog(target));

                    const color = newContentLine.querySelector(`[sw-script-body="color"]`).textContent;
                    // If script body is a character then create character in the web db
                    if (isCharacter) {
                        const isCharacterNameExist = window.CharacterHandle.checkStore(currentText);
                        if (isCharacterNameExist.valid) { /*this means character name exist, 
                            render the character id on the previous content-line */
                            conl.querySelector(`[sw-charater-data="id"]`).textContent = isCharacterNameExist.id;
                            conl.querySelector(`[sw-charater-data="id"]`).setAttribute('sw-character-idvalue', isCharacterNameExist.id);
                        } else {
                            // create new charater
                            const newCharacterId = window.CharacterHandle.create(currentText);
                            conl.querySelector(`[sw-charater-data="id"]`).textContent = newCharacterId;
                            conl.querySelector(`[sw-charater-data="id"]`).setAttribute('sw-character-idvalue', newCharacterId);
                            // Update the Character store color
                            window.ScriptDataStore.character[newCharacterId].color = color;
                        }
                    }
                }).then(()=>{
                    /** Watcher reaction */
                    window.Watcher.changeInLine(clID);
                }).then(()=> {
                    // Rearrange pages if need be
                    this.rearrangePage();
                }).then(()=> {
                    // Cause new script body element to have focus
                    //const newCls = document.querySelectorAll(`[sw-data="content-line"]`);
                    //const index = getEleId(newContentLine, newCls);
                    //newCls[index].querySelector(`[sw-data="script-body"]`).click();
                    //newCls[index]?.querySelector(`[sw-data="script-body"]`).focus();
                    newContentLine?.querySelector(`[sw-data="script-body"]`).focus()
                });
                
            } else if (pressedKey === 'ArrowUp') {
                // Move the focus behaviour to the script body element above the current one
                const allCls = document.querySelectorAll(`[sw-data="content-line"]`);
                const index = getEleId(conl, allCls) - 1;
                if (allCls[index]) {
                    allCls[index].querySelector(`[sw-data="script-body"]`).click();
                    allCls[index].querySelector(`[sw-data="script-body"]`).focus();
                }
            } else if (pressedKey === 'ArrowDown') {
                // Move the focus behaviour to the script body element below the current one
                const allCls = document.querySelectorAll(`[sw-data="content-line"]`);
                const index = getEleId(conl, allCls) + 1;
                if (allCls[index]) {
                    //setTimeout(() => {
                    allCls[index].querySelector(`[sw-data="script-body"]`).click();
                    allCls[index].querySelector(`[sw-data="script-body"]`).focus();
                    //}, 1);
                }
            } else if (pressedKey === 'Backspace') {
                const allCls = document.querySelectorAll(`[sw-data="content-line"]`);
                if (currentText === '') {
                    if (allCls.length > 1) {
                        // Get previous sibling index
                        const pIndex = getEleId(conl, allCls) - 1
                        conl.remove();
                        /** Watcher reaction */
                        window.Watcher.removeLine(clID);
                        // If a page is empty, then remove it.
                        this.removeBlankPage();
                        // move the cusor to the end of the text
                        if (allCls[pIndex]) {
                            const previousCl = allCls[pIndex].querySelector(`[sw-data="script-body"]`);
                            previousCl.focus();
                            document.execCommand('selectAll', false, null);
                            // collapse selection to the end
                            document.getSelection().collapseToEnd();
                        } 
                        // Rearrange page backward
                        this.rearrangePageBack();
                        // If a page is empty, then remove it.
                        this.removeBlankPage();
                    } else {
                        /** Watcher reaction */
                        window.Watcher.removeLine(clID);
                        // create new content line element
                        this.createNewLine(conl);
                        // delete the content line
                        conl.remove();
                    }
                }
            }
        });

        scriptLine?.addEventListener('input', (e)=> {
            //console.log(key);
            //console.log('Input Change on ', scriptLine.parentElement.getAttribute('contentline-id'));
            const completeKeyPressPromise = new Promise((resolve, reject) => { resolve(1)});
            completeKeyPressPromise.then(()=> {
                this.formatNewLineText(conl);
            }).then(()=> {
                /** Watcher reaction */
                window.Watcher.changeInLine(clID);
                // Automatically save the script data.
                //window.ScriptAdapter.autoSave();
            }).catch((error) => {
                alert('And internal error has occured: ', error);
            })
        });
    }

    /** create new content line element and append in after a previous existing contentLine, then return then newly created element*/
    createNewLine(conl, callback=(newConl)=>{}, publish=true, text='', artID='') {
        /* conl must be an existing content line inside the page.
            if publish is true then MapAndReactOnContent.mapreact() will fire,
            because the newly created content line element will be added to the page. 
        */
        // id must be created before append the newly created Content line
        const scriptBodyID = artID || this.generateID();
                
        // New Script Element Body
        const newContentLine = this.contentLineTemp?.cloneNode(true); //conl.cloneNode(true);
        const newScriptBody = newContentLine.querySelector(`[sw-data="script-body"]`);
        if (newScriptBody) newScriptBody.innerHTML = text;
        newContentLine.setAttribute('contentline-id', scriptBodyID);
        // Set new id
        newContentLine.querySelector(`[sw-script-body="id"]`).textContent = scriptBodyID;
        newContentLine.querySelector(`[sw-script-body="id"]`).setAttribute('sw-script-body-idvalue', scriptBodyID);
        // Set Color
        const color = window.BackgroundColor.randomBg();
        newContentLine.querySelector(`[sw-script-body="color"]`).textContent = color;

        // Update the newly created content-line var
        this.newlyCreatedContentLine = newContentLine;
        // Neutralize the new script element body
        this.swHandleContentLineNuetral(newScriptBody);

        // fire the callback function is there is any
        callback(newContentLine);

        if (publish) {
            // Append the new created element
            conl.insertAdjacentElement('afterend', newContentLine);

            // Add event listeners
            this.hoverSelf(newContentLine);
            this.keyPressSelf(newContentLine);

            /** Watcher for new content line */
            const clID = conl.getAttribute('contentline-id');// id of the content line
            window.Watcher.newLine(scriptBodyID, clID);

            // new available content line status
            this.freshContentLineAvalible = true;
        }


        return newContentLine;
    }

    /**Function that will format text to new conntentLine if the contentLine text has \n */
    formatNewLineText(conl) {
        let lines = conl.querySelector(`[sw-data="script-body"]`).innerText.split('\n');
        const lastLine = lines.pop();
        if (lastLine) lines.push(lastLine);
        
        if (lines.length <= 1) return;

        if (lines.length <= 30) {
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                let newContentLine;
                if (i === 0){ newContentLine = this.createNewLine(conl, ()=>{}, true, line); conl.remove();}
                else newContentLine = this.createNewLine(this.newlyCreatedContentLine, ()=>{}, true, line);
                
                // character indicator
                let isCharacter = false;

                // Run type of script body
                if (this.swHandleExtType(newContentLine));
                else if (this.swHandleIntType(newContentLine));
                else if (this.swHandleCharater(newContentLine)) isCharacter = true;
                else if (this.swHandleParentArticle(newContentLine));
                else if (this.swHandleDialog(newContentLine));

                /** Watcher for new content line */
                const clID = newContentLine.getAttribute('contentline-id');// id of the content line
                window.Watcher.changeInLine(clID);

                const color = newContentLine.querySelector(`[sw-script-body="color"]`).textContent;
                // If script body is a character then create character in the web db
                if (isCharacter) {
                    const isCharacterNameExist = window.CharacterHandle.checkStore(line);
                    if (isCharacterNameExist.valid) { /*this means character name exist, 
                        render the character id on the previous content-line */
                        newContentLine.querySelector(`[sw-charater-data="id"]`).textContent = isCharacterNameExist.id;
                        newContentLine.querySelector(`[sw-charater-data="id"]`).setAttribute('sw-character-idvalue', isCharacterNameExist.id);
                    } else {
                        // create new charater
                        const newCharacterId = window.CharacterHandle.create(line);
                        newContentLine.querySelector(`[sw-charater-data="id"]`).textContent = newCharacterId;
                        newContentLine.querySelector(`[sw-charater-data="id"]`).setAttribute('sw-character-idvalue', newCharacterId);
                        // Update the Character store color
                        window.ScriptDataStore.character[newCharacterId].color = color;
                    }
                }
                this.newlyCreatedContentLine = newContentLine;
            }
        } else {
            conl.querySelector(`[sw-data="script-body"]`).innerText = lines[0];
            alert('Are you trying to do a deep edit? switch to Editor mode.')
        }
    }

    /**
    * list of Functions controlling the script Body content / content-line
    */
    swHandleExtType (scriptBody) {
        // EXT.
        // Checker if action on script content line execute successfully
        let verify = false;
    
        if (scriptBody.innerText.toLowerCase().startsWith('ext.')) {
            // add bold to the INT. text
            scriptBody.classList.add('bold');
            // Increase Text Size
            scriptBody.classList.add('ft-size16');
            // Convert the text to Upper case
            scriptBody.innerText = scriptBody.innerText.toUpperCase();
            // Increase the padding - top and bottom by 1rem
            scriptBody.parentElement.classList.add('rem-py1');
            // Add upper Case
            scriptBody.classList.add('uppercase');
            // Add content Line signature
            scriptBody.parentElement.setAttribute('meta-type', 'scene-heading');
            // confirm checker
            verify = true;
        }
    
        return verify;
    }
    
    swHandleIntType (scriptBody) {
        // INT.
        // Checker if action on script content line execute successfully
        let verify = false;
    
        if (scriptBody.innerText.toLowerCase().startsWith('int.')) {
            // add bold to the INT. text
            scriptBody.classList.add('bold');
            // Increase Text Size
            scriptBody.classList.add('ft-size16');
            // Convert the text to Upper case
            scriptBody.innerText = scriptBody.innerText.toUpperCase();
            // Add upper Case
            scriptBody.classList.add('uppercase');
            // Increase the padding - top and bottom by 1rem
            scriptBody.parentElement.classList.add('rem-py1');
            // Add content Line signature
            scriptBody.parentElement.setAttribute('meta-type', 'scene-heading');
            // confirm checker
            verify = true;
        }
    
        return verify;
    }
    
    swHandleDialog (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
    
        // targeting charater element
        if (scriptBody.parentElement.previousElementSibling) {
            const contentLineAbove = scriptBody.parentElement.previousElementSibling;
            const metaType = contentLineAbove.getAttribute('meta-type');
            if (metaType === 'character' || metaType === 'parathentical') {
                // Adjust the script-boy colume
                scriptBody.classList.replace('col-12', 'col-9');
                // Increase the content-line padding bottom by 1rem
                scriptBody.parentElement.classList.add('rem-pb1');
                // Add content Line signature
                scriptBody.parentElement.setAttribute('meta-type', 'dialog');
                // confirm checker
                verify = true;
            }
        }
    
        return verify
    }
    
    swHandleCharater (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
        const transitionNames = ['fade in:', 'cut to:', 'back to:', 'fade out:'];
        const sbText = scriptBody.innerText;
        if (sbText /* && sbText.split().length === 1 */ && sbText.toUpperCase() === sbText) {
            scriptBody.parentElement.classList.add('rem-pb01');
            // New set
            scriptBody.classList.replace('col-12', 'col-7');
            // Add upper Case
            scriptBody.classList.add('uppercase');
            // Add content Line signature
            scriptBody.parentElement.setAttribute('meta-type', 'character');
            // confirm checker
            verify = true;
        }
    
        return verify
    }
    
    swHandleParentArticle (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
    
        const sbText = scriptBody.innerText;
        if (sbText.startsWith('(') && sbText.endsWith(')')) {
            // New set
            scriptBody.classList.replace('col-12', 'col-8');
            // Add content Line signature
            scriptBody.parentElement.setAttribute('meta-type', 'parathentical');
            // confirm checker
            verify = true;
        }
    
        return verify;
    }
    
    swHandleContentLineNuetral (scriptBody) {
        const contentLine = scriptBody.parentElement;
        contentLine.setAttribute('meta-type', 'action');
        contentLine.removeAttribute('sw-focused');
        contentLine.classList.remove('rem-py1');
        contentLine.classList.remove('rem-pb1');
        contentLine.classList.remove('rem-pb01');
        contentLine.classList.remove('rem-pb03');
        contentLine.classList.remove('rem-pb05');
        // Adjust script body
        scriptBody.classList.remove('bolder');
        scriptBody.classList.remove('bold');
        scriptBody.classList.remove('ft-size16');
        scriptBody.classList.replace('col-7', 'col-12');
        scriptBody.classList.replace('col-8', 'col-12');
        scriptBody.classList.replace('col-9', 'col-12');
        scriptBody.classList.remove('uppercase');
    }
    /* ends here */

    rearrangePage(pageAttr='') {
        const allPage = document.querySelectorAll(pageAttr||`[sw-page-pack="item"]`);
        // get total number of pages
        const tnp = allPage.length;
        //
        for (let index = 0; index < tnp; index++) {
            const page = allPage[index]; // The Page
            //Get the page scroll height
            const currentScrollHeight = page.scrollHeight;
            // Condition for new page
            if (currentScrollHeight > this.swPageHeight) {
                // Check if the page has a sibling. If no sibling then create a new page, else append last content-line to the sibling
                const nextPage = page.nextElementSibling;
                //the last content-line in the page
                const lastContentLine = page.lastElementChild;
                if (nextPage) {
                    // will be append as the first content-line in this nextpage
                    if (lastContentLine) nextPage.insertAdjacentElement('afterbegin', lastContentLine);
                    /* while (true) {
                        if (page.scrollHeight > this.swPageHeight) {
                            const lastOPage = page.lastElementChild;
                            if (lastOPage) nextPage.insertAdjacentElement('afterbegin', lastOPage);
                            else break;
                        } else {
                            const firstOfNextPage =  nextPage.firstElementChild;
                            if (firstOfNextPage) page.insertAdjacentElement('beforeend', firstOfNextPage); 
                            break
                        }
                    } */
                } else {
                    // create new page and append it to the page list
                    if (!pageAttr) {
                        const newPage = this.swPageTemp.cloneNode(true);
                        //Remove all previous children from the new page
                        [...newPage.children].forEach((cl) => {cl.remove()});
                        // Append new page to Page List
                        this.swPageWrapperTemp.append(newPage);
                        // Append the last content-line to the new page
                        newPage.insertAdjacentElement('afterbegin', lastContentLine);
                    } else {
                        const newPage = window.EditorMode.itemTemp.cloneNode(true);
                        //Remove all previous children from the new page
                        [...newPage.children].forEach((cl) => {cl.remove()});
                        window.EditorMode.editorModeList.append(newPage);
                        newPage.insertAdjacentElement('afterbegin', lastContentLine);
                    }
                }
            }

            //Now check if the page height is now accurate
            if (allPage[index].scrollHeight > this.swPageHeight) this.rearrangePage(pageAttr);
        }
    }
    
    rearrangePageBack(pageAttr='') {
        const allPage = document.querySelectorAll(pageAttr||`[sw-page-pack="item"]`); // [sw-editor-mode="item"]
        // get total number of pages
        const tnp = allPage.length;
        //
        window.MapAndReactOnContent.pageMutationStatus = false;
        for (let index = 0; index < tnp; index++) {
            const page = allPage[index]; // The Page

            // Condition for new page
            console.log(page.childElementCount, page.childElementCount < 32)
            if (page.scrollHeight <= this.swPageHeight-40 || page.childElementCount < 31) {
                // Check if the page has a sibling. If no sibling then end func., else append first content-line of the sibling to the page
                const nextPage = page.nextElementSibling;
                if (nextPage) {
                    const firstContentLine = nextPage.firstElementChild; //the first content-line in the nextpage
                    // will be append as the first content-line in this nextpage
                    if (firstContentLine) page.insertAdjacentElement('beforeend', firstContentLine);
                    while (true) {
                        if (page.scrollHeight <= this.swPageHeight-40 || page.childElementCount < 32) {
                            const firstOfNextPage = nextPage.firstElementChild;
                            if (firstOfNextPage) page.insertAdjacentElement('beforeend', firstOfNextPage);
                            else break;
                        } else {
                            const lastOfPrevPage =  page.lastElementChild;
                            if (lastOfPrevPage) nextPage.insertAdjacentElement('afterbegin', lastOfPrevPage); 
                            break
                        }
                    }
                }
            }
            //Now check if the page height is now accurate
            //if (allPage[index].scrollHeight > this.swPageHeight) this.rearrangePage(pageAttr);
        }
        window.MapAndReactOnContent.pageMutationStatus = true;
    }

    removeBlankPage(pageAttr='') {
        const allPage = document.querySelectorAll(pageAttr||`[sw-page-pack="item"]`);
        allPage.forEach((page) => {
            if (![...page.children].length) page.remove();
        });
    }

    totalNumberOfPage() {
        const tnp = document.querySelectorAll(`[sw-page-pack="item"]`).length;
        document.querySelector(`[sw-number="totalpage"]`).innerText = String(tnp);

        // Calculate time to read the content given that a page stand for 1min
        if (tnp === 60){
            document.querySelector(`[sw-number="time"]`).innerText = '1h:0m';
        } else if (tnp > 60) {
            const numOfHours = Number(String(tnp/60).split('.')[0]);
            const numOfMins = (numOfHours*60)-tnp;
            document.querySelector(`[sw-number="time"]`).innerText = String(numOfHours) + 'h:' + String(numOfMins) + 'm';
        } else {
            document.querySelector(`[sw-number="time"]`).innerText = '0h:' + String(tnp) + 'm';
        }
    }
}

/* document.addEventListener("DOMContentLoaded", function(){
    new EditorFuncs();
}); */
document.addEventListener("DOMContentLoaded", function(){
    window.EditorFuncs = new EditorFuncs();
})
