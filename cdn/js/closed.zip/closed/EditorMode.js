class EditorMode {
    editorModeList;
    editorModeItem;
    switch;
    pageHeight = 1130;
    switchStatus = false;
    currentLineList = {};
    // constants
    vars;
    // attribute name
    attrName = `sw-editor-mode`;
    // new db array
    dbArray = {};
    // later ids
    idList = [];
    // loading content status
    loadStatus = true;
    // watcher completed status
    watcherStatus = true;
    // latest line created
    latestLine;
    // key pressed
    keyPressed = '';
    constructor() {
        this.vars = {
            list: `[${this.attrName}="list"]`, item: `[${this.attrName}="item"]`, switch: `[${this.attrName}="switch"]`,
            contentLine: `[sw-data="content-line"]`, line: `[${this.attrName}-type]`,
        };
        this.editorModeList = document.querySelector(this.vars.list);
        this.editorModeItem = document.querySelector(this.vars.item);
        this.itemTemp = this.editorModeItem.cloneNode(true);
        this.lineTemp = document.querySelector(this.vars.line).cloneNode(true);
        // this must be an input element
        this.switch = document.querySelector(this.vars.switch);

        // Listeners of the editor list
        this.listener();
    }

    listener() {
        // switcher mode listener
        this.switch?.addEventListener('change', ()=>{
            window.Watcher.mainPageAwait();
            if (this.loadStatus){
                setTimeout(() => {
                    this.loadStatus = !this.loadStatus;
                    if (this.switch.checked)  this.load();
                    else this.updateMainContent();
                },20);
            } else this.switch.checked = !this.switch.checked;
        });

        //listen for key pressed and react
        this.editorModeList?.addEventListener('keydown', (e)=> {
            e.stopImmediatePropagation();
            e.stopPropagation();
            if (e.key === 'Enter') {
                this.keyPressed = 'Enter';
                setTimeout(() => {this.watcher()});
            } else if (e.key === 'Backspace') {
                this.keyPressed = 'Backspace';
                /* setTimeout(() => {
                    //window.EditorFuncs?.rearrangePage(this.vars.item);
                    window.EditorFuncs?.rearrangePageBack(this.vars.item);
                    window.EditorFuncs?.removeBlankPage(this.vars.item);
                }, 20) */
                //this.watcher();
                //if(this.watcherStatus){this.watcherStatus = false; setTimeout(() => { this.watcher() }, 20)}; 
            } else {
                /* this.keyPressed = '';
                if(this.watcherStatus){this.watcherStatus = false; setTimeout(() => { this.watcher() }, 20)};//setTimeout(() => { this.watcher();}, 20);
             */}
        });

        this.editorModeList.addEventListener('input', (e)=> {
            e.stopImmediatePropagation();
            e.stopPropagation();
            //e.preventDefault();
            if (this.keyPressed === 'Enter'){
                //this.keyPressed = '';
                console.log('enter Input');
            }else if (this.keyPressed === 'Backspace'){
                console.log('backspace Input');
                this.keyPressed = '';
                setTimeout(() => {
                    window.EditorFuncs?.rearrangePageBack(this.vars.item);
                    window.EditorFuncs?.removeBlankPage(this.vars.item);
                });
            } else {
                this.keyPressed = '';
                if(this.watcherStatus){this.watcherStatus = false;  this.watcher() };
            }
        });

        /* this.editorModeList.addEventListener('contextmenu', (e)=> {
            //e.preventDefault();
            this.keyPressed = '';
            if(this.watcherStatus){this.watcherStatus = false; setTimeout(() => { this.watcher() }, 20)};//setTimeout(() => { this.watcher();}, 20);
            
        }); */
    }

    generateID() {
        let id = '0';
        const allScriptBody = document.querySelectorAll(this.vars.line);
        const lastScriptBody = allScriptBody[(allScriptBody.length - 1)];
        if (lastScriptBody) {
            const xid = lastScriptBody.getAttribute('sw-editor-mode-id');
            if (xid) id += String(Number(xid.substr(1)) + 1);
            else id += '0';
        } else id += '0';
        
        const scriptIDList = [];
        document.querySelectorAll(this.vars.line).forEach((i) => { scriptIDList.push(i.getAttribute('sw-editor-mode-id')); });
        let count = 0;
        while (true) {
            count += 1;
            if (scriptIDList.includes(id)) {
                id = '0';
                if (lastScriptBody) {
                    const xid = lastScriptBody.getAttribute('sw-editor-mode-id');
                    if (xid) id += String(Number(xid.substr(1)) + count);
                    else id += String(count);
                } else id += String(count);
            } else break;
        }

        return id;
    }

    watcher() {
        // make sure lines are well arranged
        const rangeLinesWaiter = new Promise((resolve, reject)=>{ resolve(1) });
        rangeLinesWaiter.then(()=>{
            return this.rangeLines();
        }).then(()=>{
        }).then(() => {
            if (this.keyPressed !== 'Enter') return;
            window.EditorFuncs?.rearrangePage(this.vars.item);/* 
            window.EditorFuncs?.rearrangePageBack(this.vars.item);
            window.EditorFuncs?.removeBlankPage(this.vars.item); */
            //console.log('done with rearrange')
        }).then(() => {
            if (this.keyPressed !== 'Enter') return;
            setTimeout(()=>{
                // trap to catch newly created line
                for (let i = 0; i < this.idList.length; i++) {
                    const x = this.idList[i]; // might be the duplicated id
                    //const lenth = this.idList.filter( d => d === x ).length;
                    const duplicates = document.querySelectorAll(`[sw-editor-mode-id="${x}"]`);
                    if (duplicates.length > 1) {
                        //console.log(duplicates);
                        //const duplicates = document.querySelectorAll(`[sw-editor-mode-id="${x}"]`);
                        const newID = this.generateID(); // Check if its a another new line created
                        const target = duplicates[0]; // previous line
                        const newCreatedElement = duplicates[1]; // the newly created element
                        this.formatContentLine(target); // format previous line
                        this.handleContentLineNuetral(newCreatedElement);
                        newCreatedElement.setAttribute('sw-editor-mode-id', newID);
                        newCreatedElement.focus();
                        
                        // remove the duplicated id
                        this.idList.pop(x)
                        // Add the new created id
                        this.idList.push(newID);
                        break;
                    }
                }
            });
        }).then(() => {
            const lines = document.querySelector(this.vars.line);
            // if lines is empty
            if (!lines) this.editorModeList.append(this.itemTemp.cloneNode(true));
        }).then(()=>{
            this.watcherStatus = true;
            //console.log('watcher completed', new Date().getMilliseconds());
        });
        return rangeLinesWaiter;
    }

    rangeLines() {
        this.idList = [];
        const pageList = [...this.editorModeList.children];
        // To capture all content lines along side with the newly created ones
        const committedLines = [];
        // To signify when contentlines has to be reloaded.
        let committedStatus = false;
        // last id
        let lastID = 0;
        // if committed, content line to move to
        let lastLineTop = 0;
        const rangePromise = new Promise((resolve, reject) => {resolve(1)})
        rangePromise.then(()=> {
            pageList.forEach((page) => {
                const contentLines = [...page.children];
                contentLines.forEach((conl) => {
                    const getTheId = conl.getAttribute('sw-editor-mode-id');
                    if (!this.idList.includes(getTheId)) this.idList.push(getTheId);
    
                    const divs = conl.querySelectorAll(`[sw-editor-mode-type]`);
                    let textList = conl.innerText.split('\n');

                    const lastLine = textList.pop();
                    if (lastLine) textList.push(lastLine);
                    if (textList.length <= 1) return;

                    console.log(textList, divs);
                    //if (divs.length>1) {console.log(divs.length);}
                    let detected = false;
    
                    if (divs.length) {
                        if (divs.length <= 30) {
                            for (let index = 0; index < divs.length; index++) {
                                const div = divs[index];
                                const divId = div.getAttribute('sw-editor-mode-id');
                                if (!this.idList.includes(divId)) this.idList.push(divId);
                                else {
                                    let newID = '';
                                    if (!lastID) {newID = this.generateID(); lastID = Number(newID.substr(1));}
                                    else {newID = '0'+(lastID+1); lastID = lastID + 1;}
                                    div.setAttribute('sw-editor-mode-id', newID);
                                    //this.idList.push(newID);
                                }
            
                                if (index === 0) {
                                    conl.insertAdjacentElement('afterend', div);
                                    if (!detected) { detected = true; conl.remove(); }
                                } else this.latestLine.insertAdjacentElement('afterend', div);
            
                                // set latest accessed line
                                this.latestLine = div;
                                // format new line
                                this.formatContentLine(div);
                                // re arrange pages
                                window.EditorFuncs?.rearrangePage(this.vars.item);
                            };
                        } else {
                            //console.log('committed detected');
                            // This section means that the content lines has to be committed
                            committedStatus = true;
                            lastLineTop = page.offsetTop + conl.offsetTop;
                            for (let index = 0; index < divs.length; index++) {
                                const div = divs[index];
                                const divId = div.getAttribute('sw-editor-mode-id');
    
                                if (index === 0) if (!detected) { detected = true; conl.remove(); };
    
                                if (!this.idList.includes(divId)) this.idList.push(divId);
                                else {
                                    let newID = '';
                                    if (!lastID) {newID = this.generateID(); lastID = Number(newID.substr(1));}
                                    else {newID = '0'+(lastID+1); lastID = lastID + 1;}
                                    div.setAttribute('sw-editor-mode-id', newID);
                                    //this.idList.push(newID);
                                }
                                committedLines.push(div);
                            }
                        }
                    } else if (textList.length > 1) {
                        if (textList.length <= 30) {
                            for (let index = 0; index < textList.length; index++) {
                                const text = textList[index];    
                                const div = this.lineTemp.cloneNode(true);
                                // generate new id and assign it
                                //const newID = this.generateID();
                                let newID = '';
                                if (!lastID) {newID = this.generateID(); lastID = Number(newID.substr(1));}
                                else {newID = '0'+(lastID+1); lastID = lastID + 1;}
                            
                                div.setAttribute('sw-editor-mode-id', newID);
    
                                div.innerText = text;
    
                                if (index === 0) {
                                    conl.insertAdjacentElement('afterend', div);
                                    if (!detected) { detected = true; conl.remove(); }
                                } else this.latestLine.insertAdjacentElement('afterend', div);
                                // set latest accessed line
                                this.latestLine = div;
                                // format new line
                                this.formatContentLine(div);
                                // re arrange pages
                                window.EditorFuncs?.rearrangePage(this.vars.item);
                            }
                        } else {
                            //console.log('committed detected');
                            committedStatus = true;
                            lastLineTop = page.offsetTop + conl.offsetTop;
                            for (let index = 0; index < textList.length; index++) {
                                const text = textList[index];    
                                const div = this.lineTemp.cloneNode(true);
                                div.innerText = text;
                                
                                if (index === 0) { 
                                    const newID = this.generateID();
                                    div.setAttribute('sw-editor-mode-id', '0'+newID);
                                    detected = true; 
                                    conl.remove();
                                    lastID = Number(newID.substring(1));
                                } else {
                                    const newID = lastID+1;
                                    div.setAttribute('sw-editor-mode-id', '0'+newID);
                                    lastID = newID;
                                }
                                this.idList.push('0'+lastID);
                                this.formatContentLine(div);
                                committedLines.push(div);
                            }
                        }
                    }
    
                    if (!detected){
                        committedLines.push(conl);
                        const spanCheck = conl.querySelector('span');
                        if (spanCheck) conl.innerHTML = conl.innerText;
                    }
                });
            });
        }).then(() => {
            if (!committedStatus) return;
            // clear all page item
            pageList.forEach(e => e.remove());

            let newItem = this.itemTemp.cloneNode(true);
            this.editorModeList.append(newItem);

            [...newItem.children].forEach(e => e.remove());

            committedLines.forEach((ele) => {
                if (newItem.scrollHeight > window.EditorFuncs.swPageHeight) {
                    //the last content-line in the page
                    const lastContentLine = newItem.lastElementChild;
                    // create new page
                    newItem = this.itemTemp.cloneNode(true);;
                    this.editorModeList.append(newItem);
                    //Remove previous children or content-line from new page
                    [...newItem.children].forEach((cl) => {cl.remove()});
                    // Append last content first on new page
                    newItem.append(lastContentLine);
                }
                newItem.append(ele);
            });
        }).then(()=> {
            if (!committedStatus) return;
            //console.log('last line to top: ',lastLineTop);
            window.scrollTo(0, lastLineTop);
        }).then(()=>{
            //console.log('range lines completed');
        });
        return rangePromise;
    }

    formatContentLine(newLine, phase=1) {
        if (phase === 1) {
            this.handleContentLineNuetral(newLine);
            if (this.handleSceneHeadingType(newLine));
            else if (this.handleCharater(newLine));
            else if (this.handleParentArticle(newLine));
            else if (this.handleDialog(newLine));
        } else if (phase === 2) {
            const metaType =  newLine.getAttribute('sw-editor-mode-type');
            // remove all classes
            newLine.classList.forEach((cls) => {newLine.classList.remove(cls) });
            if (metaType === 'action') {newLine.classList.add('action-type');}
            else if (metaType === 'dialog') {newLine.classList.add('dialog-type');}
            else if (metaType === 'character') {newLine.classList.add('character-type');}
            else if (metaType === 'scene-heading') {newLine.classList.add('scene-heading-type');}
            else if (metaType === 'parathentical') {newLine.classList.add('parathentical-type');}
            else if (metaType === 'transition') {newLine.classList.add('transition-type');}
        }
    }

    load() {
        const loadPromise = new Promise((resolve, reject)=>{ resolve(1) });
        loadPromise.then(() => {
            //console.log('loading line content starts', new Date().getMilliseconds());
            // make the editor mode visible
            this.editorModeList.classList.remove('hide');
            window.EditorFuncs?.swPageWrapperTemp.parentElement.classList.add('hide');

            // Reset the id list
            this.idList = [];

            const contentLineList = document.querySelectorAll(this.vars.contentLine);

            // clear all page item
            [...this.editorModeList.children].forEach(e => e.remove());

            let newItem = this.itemTemp.cloneNode(true);
            this.editorModeList.append(newItem);

            if (contentLineList.length > 0) {
                [...newItem.children].forEach(e => e.remove());

                contentLineList.forEach((ele) => {
                    const idValue = ele.getAttribute('contentline-id');
                    const scriptBody = ele.querySelector(`[sw-data="script-body"]`);
                    const metaType = ele.getAttribute('meta-type');
                    // new line element
                    const newLine = this.lineTemp.cloneNode(true);
                    newLine.setAttribute('sw-editor-mode-type', metaType);
                    newLine.setAttribute('sw-editor-mode-id', idValue);
                    newLine.innerHTML = scriptBody.innerHTML;

                    if (newItem.scrollHeight > window.EditorFuncs.swPageHeight) {
                        //the last content-line in the page
                        const lastContentLine = newItem.lastElementChild;
                        // create new page
                        newItem = this.itemTemp.cloneNode(true);;
                        this.editorModeList.append(newItem);
                        //Remove previous children or content-line from new page
                        [...newItem.children].forEach((cl) => {cl.remove()});
                        // Append last content first on new page
                        newItem.append(lastContentLine);
                    }
                    newItem.append(newLine);

                    // format new line
                    this.formatContentLine(newLine, 2);
                });
            }
        }).then(() => {
            //console.log('loading content ends', new Date().getMilliseconds());
            //console.log('re-arranging contents starts', new Date().getMilliseconds());
            window.EditorFuncs?.rearrangePage(this.vars.item);
        }).then(() => {
            /** Await Starts*/
            window.Watcher.mainPageAwait(false);
            //console.log('re-arranging contents ends', new Date().getMilliseconds());
            // Enable load status
            this.loadStatus = true;
        });
    }

    updateMainContent() {
        const updaterPromise = new Promise((resolve, reject)=>{ resolve(1) });
        updaterPromise.then(()=>{
            this.dbArray = {};
            const lines = document.querySelectorAll(this.vars.line);
            const draftKey = window.ScriptAdapter.currentDraftKey;
            const dataset = window.ScriptDataStore.draft[draftKey].data;

            lines.forEach((line) => {
                const idValue = line.getAttribute('sw-editor-mode-id');
                const metaType = line.getAttribute('sw-editor-mode-type');
                const scriptBody = line.innerHTML;
        
                const mydb = dataset[idValue];
                if (mydb) {
                    this.dbArray[idValue] = {
                        id: idValue, body: scriptBody, content: scriptBody, type: metaType,  color: mydb.color,
                        others: mydb.others, note: mydb.note, comment: mydb.comment,
                    }
                } else {
                    this.dbArray[idValue] = {
                        id: idValue, body: scriptBody, content: scriptBody, type: metaType,
                        color: window.BackgroundColor.randomBg(), others: {},
                        note:{text:'', authorID: '', authorName: '', date: '', color: ''}, 
                        comment:{text: '', authorID: '', authorName: '', date: ''}
                    };
                    
                    if (metaType === 'character') this.dbArray[idValue].others.cid = window.CharacterHandle?.create(line.innerText);
                    else if (metaType === 'scene-heading') this.dbArray[idValue].others = {ev: '0', scenegoal: ''};
                }
            });
        }).then(() => {
            //console.log(this.dbArray);
            // make the editor mode hidden
            this.editorModeList.classList.add('hide');
            window.EditorFuncs?.swPageWrapperTemp.parentElement.classList.remove('hide');
            [...window.EditorFuncs?.swPageWrapperTemp.children].forEach(e => e.remove());
        }).then(()=> {
            const draftKey = window.ScriptAdapter.currentDraftKey;
            window.ScriptDataStore.draft[draftKey].data = this.dbArray;
            return window.ScriptAdapter?.renderDraftContent(draftKey, ()=>{window.Watcher.saveCaller()}, true);
        }).then(()=>{
            // Enable load status
            this.loadStatus = true;
            [...this.editorModeList.children].forEach(e => e.remove());
        })
            
        
    }

    handleSceneHeadingType (scriptBody) {
        // INT. or EXT.
        // Checker if action on script content line execute successfully
        let verify = false;
        if (scriptBody.innerText.toLowerCase().startsWith('int.') || scriptBody.innerText.toLowerCase().startsWith('ext.')) {
            scriptBody.classList.replace('action-type', 'scene-heading-type');
            // Add content Line signature
            scriptBody.setAttribute('sw-editor-mode-type', 'scene-heading');
            // confirm checker
            verify = true;
        }
        return verify;
    }
    
    handleDialog (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
        // targeting charater or parent article element
        if (scriptBody.previousElementSibling) {
            const contentLineAbove = scriptBody.previousElementSibling;
            const metaType = contentLineAbove.getAttribute('sw-editor-mode-type');
            if (metaType === 'character' || metaType === 'parathentical') {
                scriptBody.classList.replace('action-type', 'dialog-type');
                // Add content Line signature
                scriptBody.setAttribute('sw-editor-mode-type', 'dialog');
                // confirm checker
                verify = true;
            }
        }
    
        return verify
    }
    
    handleCharater (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
        //const transitionNames = ['fade in:', 'cut to:', 'back to:', 'fade out:'];
        const num = '0123456789';
        const sbText = scriptBody.innerText;
        if (sbText && sbText.split('').length >= 3 && sbText.toUpperCase() === sbText && !num.includes(sbText[0])) {
            scriptBody.classList.replace('action-type', 'character-type');
            // Add content Line signature
            scriptBody.setAttribute('sw-editor-mode-type', 'character');
            // confirm checker
            verify = true;
        }
        return verify
    }
    
    handleParentArticle (scriptBody) {
        // Checker if action on script content line execute successfully
        let verify = false;
        const sbText = scriptBody.innerText;
        if (sbText.startsWith('(') && sbText.endsWith(')')) {
            scriptBody.classList.replace('action-type', 'parathentical-type');
            // Add content Line signature
            scriptBody.setAttribute('sw-editor-mode-type', 'parathentical');
            // confirm checker
            verify = true;
        }
    
        return verify;
    }
    
    handleContentLineNuetral (scriptBody) {
        // Adjust script body
        scriptBody.classList.remove('scene-heading-type');
        scriptBody.classList.remove('character-type');
        scriptBody.classList.remove('parent-article-type');
        scriptBody.classList.remove('dialog-type');
        scriptBody.classList.remove('transition-type');
        scriptBody.classList.add('action-type');
        scriptBody.setAttribute('sw-editor-mode-type', 'action');
    }
}

document.addEventListener("DOMContentLoaded", function(){
    window.EditorMode = new EditorMode();
})
