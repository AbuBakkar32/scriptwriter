
google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          [1, 28, 28, -38, -38, 'Sunspot activity made this our1'],
          [2, 38, 38, -55, -55, 'Sunspot activity made this our2'],
          [3, 55, 55, -77, -77, 'Sunspot activity made this our3'],
          [4, 77, 77, -77, -77, 'Sunspot activity made this our4'],
          [5, 66, 66, -66, -66, 'Sunspot activity made this our5']
          // Treat the first row as data.
        ], true);

        var options = {
            tooltip: {isHtml: true},
          legend: 'none',
          bar: { groupWidth: '10%' }, // Remove space between bars.
          backgroundColor: { fill: '#f5f5fa', stroke: '#000', strokeWidth: 0 },
          candlestick: {
            fallingColor: { strokeWidth: 0, fill: '#a52714' }, // red
            risingColor: { strokeWidth: 0, fill: '#0f9d58' }   // green
          },
          vAxis: { ticks: [0,0,0,0] },hAxis: { ticks: [0,0,0,0,0,0,0,7], baseline:13 }, 
          chartArea:{left:20,top:0,width:'60%',height:'90%', stroke: '#fdc', strokeWidth:50}
        };

        var chart = new google.visualization.CandlestickChart(document.querySelector(`[sw-graph="item-1"]`));
        chart.draw(data, options);
      }


google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var dataTable = new google.visualization.DataTable();
        dataTable.addColumn('number', 'Y');
        dataTable.addColumn('number', 'S');
        dataTable.addColumn('number', 't');
        dataTable.addColumn('number', 'p');
        dataTable.addColumn('number', 'p');
        // A column for custom tooltip content
        dataTable.addColumn({type: 'string', role: 'tooltip', p: {html: true}});
        dataTable.addRows([
          [1, 28, 28, -38, -38, '<b>one<b>'],
          [2, 38, 38, -55, -55, '<i>two</i>'],
          [3, 55, 55, -77, -77, '<u>three</u>'],
          [4, 77, 77, -77, -77, '<b>four</b>'],
          [5, 66, 66, -66, -66, '<b>hello<br>five</b>']
          // Treat the first row as data.
        ]);

        var options = {
            tooltip: {isHtml: true},
          legend: {position: 'bottom', textStyle: {color: 'blue', fontSize: 18}},
          bar: { groupWidth: '10%' }, // Remove space between bars.
          backgroundColor: { fill: '#f5f5fa', stroke: '#000', strokeWidth: 0 },
          candlestick: {
            fallingColor: { strokeWidth: 0, fill: '#a52714' }, // red
            risingColor: { strokeWidth: 0, fill: '#0f9d58' }   // green
          },
          vAxis: { ticks: [0,0,0,0] },hAxis: { ticks: [0,0,0,0,0,0,0,7], baseline:13 }, 
          chartArea:{left:20,top:0,width:'60%',height:'90%', stroke: '#fdc', strokeWidth:50},
        };

        var chart = new google.visualization.CandlestickChart(document.querySelector(`[sw-graph="item-1"]`));
        chart.draw(dataTable, options);
      }


    function formateStyle(){
        const lineMetaType = newLine.getAttribute('sw-editor-mode-type');
        const text = newLine.textContent;

        // format for dialog
        if (newLine.previousElementSibling) {
            const contentLineAbove = newLine.previousElementSibling;
            const metaType = contentLineAbove.getAttribute('sw-editor-mode-type');
            if (metaType === 'character' || metaType === 'parathentical') {
                if (lineMetaType !== 'dialog') {
                    this.handleContentLineNuetral(newLine);
                    this.handleDialog(newLine)
                }
            }
        }

        // Format for scene heading
        if (text.toLowerCase().startsWith('int.') || text.toLowerCase().startsWith('ext.')) {
            if (lineMetaType !== 'scene-heading') {
                this.handleContentLineNuetral(newLine);
                this.handleSceneHeadingType(newLine)
            }
        }

        // format character
        if (text && text.split('').length >= 3  && text.toUpperCase() === text) {
            if (lineMetaType !== 'character') {
                this.handleContentLineNuetral(newLine);
                this.handleCharater(newLine)
            }
        }

        // format parent article
        if (text.startsWith('(') && text.endsWith(')')) {
            if (lineMetaType !== 'parathentical') {
                this.handleContentLineNuetral(newLine);
                this.handleParentArticle(newLine);
            }
        } 
      }


      /* 
            // Use traditional 'for loops' for IE 11
            for(const mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    if (mutation.addedNodes.length) {
                        // Newly created element
                        const newCreatedElement = mutation.addedNodes[0];
                        // Check if newCreatedElement is a text or element
                        if (!newCreatedElement.length) {
                            // Check if its a new page that is created in other to add it observer and keydown event listener
                            if (newCreatedElement.getAttribute('sw-page-pack')) {
                                this.addObserver(newCreatedElement);
                                //this.addKeyDownEvent(newCreatedElement);
                                
                                // Map and react on creating of a new page
                                if (this.pageMutationStatus) this.mapreact(); 
                            }
                        }
                    } else if (mutation.removeNodes) {

                    }
                }
            } */
        
        allMetaTypeElement.forEach((el) => {
            const mainElement = el;
            const getType = el.getAttribute('meta-type'); // return either action or dialog or parathentical or scene-heading etc.
            const scriptBodyElement = el.querySelector(`[sw-data="script-body"]`);
            const uid = this.geneateUniqueID();
            const ind = count;
            // script body id
            const sbID = el.querySelector(`[sw-script-body="id"]`).innerText;
            // script body color
            const sbColor = el.querySelector(`[sw-script-body="color"]`).innerText;
            // character id
            const cid = el.querySelector(`[sw-charater-data="id"]`).innerText;
            // Get the particular page number
            const pageNumber = getEleId(el.parentElement, document.querySelectorAll(`[sw-page-pack="item"]`))+1;
            // Create/Append the array to contentStore
            if (getType === 'character') {
                const cat = {
                    main: mainElement, type: getType, content: scriptBodyElement, id: uid, index: ind, other: [], cid: cid, 
                    sbID: sbID, color: sbColor
                };
                this.contentStore.push(cat);
                // Increase the count
                count += 1;
            } else if (getType !== 'character') {
                const cat = {
                    main: mainElement, type: getType, content: scriptBodyElement, id: uid, index: ind, 
                    sbID: sbID, color: sbColor, pageNumber: pageNumber
                };
                this.contentStore.push(cat);

                // Increase the count
                count += 1;
            }

            //Append data to the DataForGraph Store
            if (getType === 'character') {
                this.dataForGraph.push({type: 'character', name: scriptBodyElement.innerText, index: dataForGraphCount});
                dataForGraphCount += 1;
            } else if (getType === 'scene-heading') {
                this.dataForGraph.push({type: 'scene-heading', name: scriptBodyElement.innerText, index: dataForGraphCount});
                dataForGraphCount += 1;
            }
        });
        




